import { combineReducers } from "redux";
import menu from './menu';


const all_reducers= combineReducers({
    menu:menu
})